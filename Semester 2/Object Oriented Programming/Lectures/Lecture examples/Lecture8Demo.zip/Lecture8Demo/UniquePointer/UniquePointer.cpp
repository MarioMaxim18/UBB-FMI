#include <iostream>
#include <memory>
#include <crtdbg.h>

class MyClass {
public:
    void greet() { std::cout << "Hello, Unique Pointer!" << std::endl; }
};

// Basic usage example
void exampleBasicUsage() {
    std::unique_ptr<MyClass> myPtr = std::make_unique<MyClass>();
    myPtr->greet();
}


// Transfer of ownership example
void exampleTransferOwnership() {    

    std::unique_ptr<int> myInt = std::make_unique<int>(42);
   
    std::cout << "My integer value: " << *myInt << std::endl;

    // Transfer ownership
    std::unique_ptr<int> myNewInt = std::move(myInt);
    
    if (!myInt) {
        std::cout << "myInt no longer owns the integer." << std::endl;
    }

    std::cout << "My new integer value: " << *myNewInt << std::endl;
}

// Array support example
void exampleArraySupport() {
    std::unique_ptr<int[]> myArray = std::make_unique<int[]>(3);
    myArray[0] = 10;
    myArray[1] = 20;
    myArray[2] = 30;

    for (int i = 0; i < 3; ++i) {
        std::cout << myArray[i] << " ";
    }
    std::cout << std::endl;
}

void accessResource(int* ptr) {
    std::cout << "accessResource: " << *ptr << std::endl;
    // The raw pointer is used here. Ownership is not transferred.
}


void accessResource(std::unique_ptr<int> ptr) {
    std::cout << "accessResource: " << *ptr << std::endl;
}

int main() {
    {
        std::cout << "Example: Basic Usage" << std::endl;
        exampleBasicUsage();

        std::cout << "\nExample: Transfer of Ownership" << std::endl;
        exampleTransferOwnership();

        std::cout << "\nExample: Array Support" << std::endl;
        exampleArraySupport();

        {
            std::unique_ptr<int> myPtr = std::make_unique<int>(99);
            accessResource(myPtr.get()); // Use get() to access the raw pointer.

            accessResource(std::move(myPtr));
            if (!myPtr) {
                std::cout << "main: myPtr is now null." << std::endl;
            }
        }
    }
    _CrtDumpMemoryLeaks();
    return 0;
}
