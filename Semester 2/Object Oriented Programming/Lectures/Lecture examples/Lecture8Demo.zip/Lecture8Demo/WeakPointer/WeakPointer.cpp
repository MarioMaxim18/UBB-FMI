#include <iostream>
#include <memory> // for shared pointer
#include <vector>
#include <string>

class Student; // Forward declaration


class Teacher {
public:

	Teacher(std::string teacherName) : name{ teacherName } { std::cout << "Teacher constructor\n"; }
	~Teacher() { std::cout << "Teacher destructed\n"; }
	void addStudent(std::shared_ptr<Student> s) {
		students.push_back(s);
	}

	std::string getName() const { return name; }

private:
	std::string name;
	std::vector<std::shared_ptr<Student>> students;
};

class Student {
public:
	Student(std::string studentName) : name{ studentName } { std::cout << "Student constructor\n"; }
	~Student() { std::cout << "Student destructed\n"; }

	void setFavouriteTeacher(std::shared_ptr<Teacher> teacher) { favoriteTeacher = teacher; }

	void printFavoriteTeacherName() {
		auto sharedTeacher = favoriteTeacher.lock(); // Convert weak_ptr to shared_ptr to access Teacher
		if (sharedTeacher) { // Check if the Teacher still exists
			std::cout << name << "'s favorite teacher is " << sharedTeacher->getName() << ".\n";
		}
		else {
			std::cout << name << "'s favorite teacher is no longer available.\n";
		}
	}


private:
	std::string name;
	std::weak_ptr<Teacher> favoriteTeacher;
};


int main() {


	auto teacher = std::make_shared<Teacher>("Best teacher");
	auto student = std::make_shared<Student>("Student");
	
	{
	
		std::cout << "(1) Teacher use count: " << teacher.use_count() << std::endl;
		std::cout << "(1) Student use count: " << student.use_count() << std::endl;

		teacher->addStudent(student);
		student->setFavouriteTeacher(teacher);

		student->printFavoriteTeacherName();

		std::cout << "(2) Teacher use count: " << teacher.use_count() << std::endl;
		std::cout << "(2) Student use count: " << student.use_count() << std::endl;
	}
	std::cout << "(3) Teacher use count: " << teacher.use_count() << std::endl;
	// Without breaking the cycle manually, neither Student nor Teacher will be destructed properly.
}