#include <iostream>

class Resource
{
public:
	Resource() { std::cout << "Resource acquired\n"; }
	~Resource() { std::cout << "Resource destroyed\n"; }
};

template<typename T>
class RAII
{
	T* m_ptr{};
public:
	RAII(T* ptr = nullptr)
		: m_ptr{ ptr }
	{
	}

	// Destructor
	~RAII()
	{
		delete m_ptr;
	}

	// Copy constructor
	RAII(const RAII& a)
	{
		m_ptr = new T;
		*m_ptr = *a.m_ptr;
	}

	// move constructor
	RAII(RAII&& a) noexcept
		: m_ptr(a.m_ptr)
	{
		a.m_ptr = nullptr; 
	}

	// move assignment
	RAII& operator=(RAII&& a) noexcept
	{
		
		if (&a != this) {
			delete m_ptr;
			m_ptr = a.m_ptr;
			a.m_ptr = nullptr;
		}
		return *this;
	}


	//  assignment
	RAII& operator=(const RAII& a)
	{
		// Self-assignment detection
		if (&a != this) {
			delete m_ptr;
			m_ptr = new T;
			*m_ptr = *a.m_ptr;
		}
		return *this;
	}

	T& operator*() const { return *m_ptr; }
	T* operator->() const { return m_ptr; }
	bool isNull() const { return m_ptr == nullptr; }
};


RAII<Resource> createResource()
{
	RAII<Resource> res{ new Resource };
	return res; // this return value will invoke the copy constructor
}

int main()
{
	RAII<Resource> mainres;
	mainres = createResource(); // this assignment will invoke the copy assignment

	return 0;
}