#include <iostream>
#include <memory>
#include <vector>

void exampleBasicUsage();
void exampleReset();
void exampleWithContainers();
void exampleWeakPtr();

void examplePassSharedPtrByValue(std::shared_ptr<int> ptr);
void examplePassSharedPtrByReference(const std::shared_ptr<int>& ptr);

int main() {
    std::cout << "Example: Basic Usage and Copying" << std::endl;
    exampleBasicUsage();

    std::cout << "\nExample: Reset and Unique" << std::endl;
    exampleReset();

    std::cout << "\nExample: Using with Standard Containers" << std::endl;
    exampleWithContainers();

    std::cout << "\nExample: Weak Pointers" << std::endl;
    exampleWeakPtr();


    std::shared_ptr<int> sharedPtr = std::make_shared<int>(100);
    std::cout << "\nPassing std::shared_ptr to a Function" << std::endl;
    std::cout << "Before function call, use count: " << sharedPtr.use_count() << std::endl;
    examplePassSharedPtrByValue(sharedPtr);
    std::cout << "After by value call, use count: " << sharedPtr.use_count() << std::endl;
    examplePassSharedPtrByReference(sharedPtr);
    std::cout << "After by reference call, use count: " << sharedPtr.use_count() << std::endl;

    return 0;
}


void exampleBasicUsage() {

    std::shared_ptr<int> ptr1 = std::make_shared<int>(10);
    std::cout << "ptr1 value: " << *ptr1 << std::endl;
    {
        // Copy the shared_ptr
        std::shared_ptr<int> ptr2 = ptr1;
        std::cout << "ptr2 value: " << *ptr2 << std::endl;

        std::cout << "use count: " << ptr1.use_count() << std::endl;
    }
    
    std::cout << "use count: " << ptr1.use_count() << std::endl;
}


void exampleReset() {
    std::shared_ptr<int> ptr = std::make_shared<int>(20);
    std::cout << "ptr value before reset: " << *ptr << std::endl;

    ptr.reset(new int(30)); // Now ptr owns a different integer
    std::cout << "ptr value after reset: " << *ptr << std::endl;
}


void exampleWithContainers() {
    std::vector<std::shared_ptr<int>> vec;

    vec.push_back(std::make_shared<int>(40));
    vec.push_back(std::make_shared<int>(50));

    for (const auto& ptr : vec) {
        std::cout << "Value in vector: " << *ptr << std::endl;
    }
}

// Weak pointers
void exampleWeakPtr() {
    std::shared_ptr<int> sharedPtr = std::make_shared<int>(60);
    std::weak_ptr<int> weakPtr(sharedPtr);

    // Check if weak pointer is valid before using
    if (auto tmpPtr = weakPtr.lock()) {
        std::cout << "Weak pointer value: " << *tmpPtr << std::endl;
    }
    else {
        std::cout << "Weak pointer is expired." << std::endl;
    }
}

void examplePassSharedPtrByValue(std::shared_ptr<int> ptr) {
    std::cout << "In function (by value), value: " << *ptr << ", use count: " << ptr.use_count() << std::endl;
    // Use count increases due to the copy
}

void examplePassSharedPtrByReference(const std::shared_ptr<int>& ptr) {
    std::cout << "In function (by reference), value: " << *ptr << ", use count: " << ptr.use_count() << std::endl;
    // Use count does not change
}
