#include <iostream>
#include <thread>
#include <vector>
#include <mutex>

int counter = 0; // Shared resource
std::mutex counterMutex; // Mutex for synchronizing access to counter

void incrementCounter(int n) {
	for (int i = 0; i < n; ++i) {
		// Lock is acquired here and automatically released at the end of the scope
	   // std::lock_guard<std::mutex> guard(counterMutex); 
		counterMutex.lock();
		++counter;
		counterMutex.unlock();
	}
}

int main() {
	int numberOfIncrements = 10000;
	std::vector<std::thread> threads;

	// Start 10 threads, each incrementing the counter 10000 times
	for (int i = 0; i < 10; ++i) {
		threads.emplace_back(incrementCounter, numberOfIncrements);
	}

	// Join all threads
	for (auto& thread : threads) {
		thread.join();
	}

	std::cout << "Expected counter value: " << 10 * numberOfIncrements << std::endl;
	std::cout << "Actual counter value: " << counter << std::endl;

	return 0;
}
