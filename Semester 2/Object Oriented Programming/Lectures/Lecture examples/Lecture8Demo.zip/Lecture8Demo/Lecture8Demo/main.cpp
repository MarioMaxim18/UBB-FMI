#include <thread>
#include <chrono>
#include <vector>
#include <iostream>
using namespace std;

void multiplyRange(double** A, double** B, double** C, int startRow, int endRow, int N) {
    for (int i = startRow; i < endRow; ++i) {
        for (int j = 0; j < N; ++j) {
            C[i][j] = 0.0;
            for (int k = 0; k < N; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// Sequential version of matrix multiplication
void multiplySequential(double** A, double** B, double** C, int N) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            C[i][j] = 0.0;
            for (int k = 0; k < N; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

int main() {
    const int N = 1000; // Matrix size
    double** A = new double* [N];
    double** B = new double* [N];
    double** C = new double* [N];

    
    for (int i = 0; i < N; ++i) {
        A[i] = new double[N];
        B[i] = new double[N];
        C[i] = new double[N];
        for (int j = 0; j < N; ++j) {
            A[i][j] = 1.0; 
            B[i][j] = 1.0;
            C[i][j] = 0.0; 
        }
    }

    const int numThreads = thread::hardware_concurrency();
    cout << "Number of threads: " << numThreads << endl;
    vector<thread> threads;
    int rowsPerThread = N / numThreads;

    auto startParallel = chrono::steady_clock::now();

    // Launch threads for parallel multiplication
    for (int i = 0; i < numThreads; ++i) {
        int startRow = i * rowsPerThread;
        int endRow = (i + 1) * rowsPerThread;
        if (i == numThreads - 1) {
            endRow = N;
        }
        threads.emplace_back(multiplyRange, A, B, C, startRow, endRow, N);
    }

    for (auto& th : threads) {
        th.join();
    }

    auto endParallel = chrono::steady_clock::now();

    cout << "Parallel execution time: "
        << chrono::duration_cast<chrono::milliseconds>(endParallel - startParallel).count()
        << " ms" << endl;

    // Reset matrix C to 0.0 for sequential multiplication
    for (int i = 0; i < N; ++i) {
        fill(C[i], C[i] + N, 0.0);
    }

    auto startSequential = chrono::steady_clock::now();

    // Perform sequential multiplication
    multiplySequential(A, B, C, N);

    auto endSequential = chrono::steady_clock::now();

    cout << "Sequential execution time: "
        << chrono::duration_cast<chrono::milliseconds>(endSequential - startSequential).count()
        << " ms" << endl;

    // Free the allocated memory
    for (int i = 0; i < N; ++i) {
        delete[] A[i];
        delete[] B[i];
        delete[] C[i];
    }
    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}
