#include <algorithm> 
#include <iostream>


#include <iostream>

template<typename T>
class SharedPtr {
private:
	T* ptr; // Pointer to the managed object
	unsigned* count; // Reference count

public:
	// Constructor
	explicit SharedPtr(T* p = nullptr) : ptr(p), count(new unsigned(p != nullptr)) {
	}

	// Copy constructor
	SharedPtr(const SharedPtr& sp) : ptr(sp.ptr), count(sp.count) {
		// Increment the reference count
		if (ptr) {
			(*count)++;
		}
	}

	// Destructor
	~SharedPtr() {
		// Decrement the ref count and delete if last
		if (ptr && --(*count) == 0) {
			delete ptr;
			delete count;
		}
	}

	// Copy assignment operator
	SharedPtr& operator=(const SharedPtr& sp) {
		if (this != &sp) {
			// Decrement the old object's reference count and delete if it was the last reference
			if (ptr && --(*count) == 0) {
				delete ptr;
				delete count;
			}
			// Copy the new object and its reference count
			ptr = sp.ptr;
			count = sp.count;
			if (ptr) {
				(*count)++;
			}
		}
		return *this;
	}

	// Dereference operator
	T& operator*() const { return *ptr; }

	// Arrow operator
	T* operator->() const { return ptr; }

	// Get the raw pointer
	T* get() const { return ptr; }

	// Get the current reference count
	unsigned use_count() const {
		return ptr ? *count : 0;
	}

	// Check if there is an associated managed object
	bool isNull() const { return ptr == nullptr; }
};


template<typename T>
class UniquePointer {
private:
	T* ptr;

public:
	// Constructor
	explicit UniquePointer(T* p = nullptr) : ptr(p) {}

	// Destructor
	~UniquePointer() {
		if (ptr) {
			delete ptr;
			ptr = nullptr;
		}
	}

	// Delete copy constructor and copy assignment to enforce uniqueness
	UniquePointer(const UniquePointer& other) = delete;
	UniquePointer& operator=(const UniquePointer& other) = delete;

	// Move constructor
	UniquePointer(UniquePointer&& other) noexcept : ptr{ other.ptr } {
		other.ptr = nullptr;
	}

	// Move assignment operator
	UniquePointer& operator=(UniquePointer&& moving) noexcept {
		if (this != &moving) { // self assignment check
			delete ptr; // Free the existing resource
			ptr = nullptr;
			std::swap(ptr, moving.ptr);
		}
		return *this;
	}

	// Dereference operator
	T& operator*() const { return *ptr; }

	// Arrow operator
	T* operator->() const { return ptr; }

	// Get the raw pointer
	T* get() const { return ptr; }

	// Release the ownership of the pointer
	T* release() {
		T* temp = ptr;
		ptr = nullptr;
		return temp;
	}

	// Check if there is an associated managed object
	bool isNull() const { return ptr == nullptr; }
};


void uniquePointerDemo() {
	UniquePointer<int> myPtr(new int(10));
	std::cout << "Value: " << *myPtr << std::endl;

	UniquePointer<int> movedPtr = std::move(myPtr);
	if (myPtr.isNull()) {
		std::cout << "myPtr is now null." << std::endl;
	}

	if (!movedPtr.isNull()) {
		std::cout << "movedPtr value: " << *movedPtr << std::endl;
	}
}


void sharedPointerDemo() {
	SharedPtr<int> ptr1(new int(10));
	std::cout << "ptr1 value: " << *ptr1 << ", count: " << ptr1.use_count() << std::endl;

	{
		SharedPtr<int> ptr2 = ptr1; // Copy constructor increases count
		std::cout << "ptr2 value: " << *ptr2 << ", count: " << ptr2.use_count() << std::endl;
	} // ptr2 goes out of scope, count decreases

	std::cout << "ptr1 value: " << *ptr1 << ", count: " << ptr1.use_count() << std::endl;

}


int main() {

	uniquePointerDemo();
	sharedPointerDemo();
	return 0;
}
